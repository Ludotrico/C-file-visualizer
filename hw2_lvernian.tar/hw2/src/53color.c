#include "../include/helpers2.h"
#include "../include/hw2.h"

int main(int argc, char* argv[]) {
    char* c_file = NULL;
    char* mapping_file = NULL;
    int lines_shown = 24;

    // Use basic getopt to parse flags and respective arguments
    int c;
    while ((c = getopt(argc, argv, "hl:k:")) >= 0) {
        switch (c) {
            case 'h':
                fprintf(stdout,USAGE_MSG);
                return EXIT_SUCCESS;
            case 'l':
                lines_shown = atoi(optarg);
                break;
            case 'k':
                mapping_file = optarg;
                break;
            default:
                fprintf(stderr, USAGE_MSG);
                return EXIT_FAILURE;
        }
    }

    // validate that we only have 1 positional argument
    if (optind + 1 != argc)
    {
        fprintf(stderr, "Exactly one positional argument should be specified.\n\n" USAGE_MSG);
        return EXIT_FAILURE;
    }
    
    c_file = *(argv + optind);

    // INSERT YOUR IMPLEMENTATION HERE
    FILE * fp = NULL;
    fp = fopen(c_file, "r");

    FILE * mappingFile;
    mappingFile = fopen(mapping_file, "r");

    list_t* linkedList = GenerateDefaultFormatMappings();


    int val = 0;
    char * input = malloc(sizeof(char)*10);
    while (1) {
        val = processLine(fp, lines_shown, linkedList);
        if (val)
            break;

        fgets(input,10,stdin);
        if ( ((*input) == 'q') || ((*input) == 'Q')  ) {
            break;
        }
    }


   //printf("\nCLEANUP\n");

    //fclose(fp);
    free(input);
    DestroyDefaultFormatMappings(linkedList);


    return 0;
}
